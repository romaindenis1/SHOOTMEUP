﻿// Bullet.cs

using System;
using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public class Bullet : Form
    {
        private Timer _bulletTimer; //timer pour bouger
        private int _speed = 100;  //vitesse de la balle

        public Bullet(string imagePath, Point initialPosition)
        {
            this.FormBorderStyle = FormBorderStyle.None; //pour ne pas avoir de borders
            this.StartPosition = FormStartPosition.Manual; 
            this.Location = initialPosition;              
            this.BackColor = Color.Black;                 

            // Load the bullet image
            PictureBox bulletImage = new PictureBox();
            bulletImage.Image = Image.FromFile(imagePath); 
            bulletImage.SizeMode = PictureBoxSizeMode.AutoSize;
            this.Size = bulletImage.Image.Size; 
            this.Controls.Add(bulletImage);  

            

            //timer de balles 
            _bulletTimer = new Timer();
            _bulletTimer.Interval = 3;           //intervale entre tick **Plus de numero le plus lent il est**
            _bulletTimer.Tick += MoveBullet;      
            _bulletTimer.Start();                
        }

        // Move the bullet upwards
        private void MoveBullet(object sender, EventArgs e)
        {
            this.Top -= _speed; 
            if (this.Top + this.Height < 0) 
            {
                _bulletTimer.Stop();
                this.Close(); 
            }
        }
    }
}
